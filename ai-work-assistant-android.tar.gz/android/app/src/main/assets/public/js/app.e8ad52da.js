import{_ as p}from"./common.3b575a10.js";import{g as q,E as D,f as X,s as Y,h as b,i as j,t as g,_ as O,j as u,V as _,C as J,H as K,T as Q,k as C,L as Z,l as H,m as N,n as F,o as nn,q as tn,v as en,w as an,x as rn,y as on,R,b as d,e as l}from"./vendors.f5906235.js";(function(){const n=document.createElement("link").relList;if(n&&n.supports&&n.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))e(o);new MutationObserver(o=>{for(const r of o)if(r.type==="childList")for(const a of r.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&e(a)}).observe(document,{childList:!0,subtree:!0});function t(o){const r={};return o.integrity&&(r.integrity=o.integrity),o.referrerPolicy&&(r.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?r.credentials="include":o.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function e(o){if(o.ep)return;o.ep=!0;const r=t(o);fetch(o.href,r)}})();var un=`
/* H5 端隐藏 TabBar 空图标（只隐藏没有 src 的图标） */
.weui-tabbar__icon:not([src]),
.weui-tabbar__icon[src=''] {
  display: none !important;
}

.weui-tabbar__item:has(.weui-tabbar__icon:not([src])) .weui-tabbar__label,
.weui-tabbar__item:has(.weui-tabbar__icon[src='']) .weui-tabbar__label {
  margin-top: 0 !important;
}

/* Vite 错误覆盖层无法选择文本的问题 */
vite-error-overlay {
  /* stylelint-disable-next-line property-no-vendor-prefix */
  -webkit-user-select: text !important;
}

vite-error-overlay::part(window) {
  max-width: 90vw;
  padding: 10px;
}

.taro_page {
  overflow: auto;
}

::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}

::-webkit-scrollbar-track {
  background: transparent;
}

::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.2);
  border-radius: 2px;
}

::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.3);
}

/* H5 导航栏页面自动添加顶部间距 */
body.h5-navbar-visible .taro_page {
  padding-top: 44px;
}

body.h5-navbar-visible .toaster[data-position^="top"] {
  top: 44px !important;
}

/* Sheet 组件在 H5 导航栏下的位置修正 */
body.h5-navbar-visible .sheet-content:not([data-side="bottom"]) {
    top: 44px !important;
}

/*
 * H5 端 rem 适配：与小程序 rpx 缩放一致
 * 375px 屏幕：1rem = 16px，小程序 32rpx = 16px
 */
html {
    font-size: 4vw !important;
}

/* H5 端组件默认样式修复 */
taro-view-core {
    display: block;
}

taro-text-core {
    display: inline;
}

taro-input-core {
    display: block;
    width: 100%;
}

taro-input-core input {
    width: 100%;
    background: transparent;
    border: none;
    outline: none;
}

taro-input-core.taro-otp-hidden-input input {
    color: transparent;
    caret-color: transparent;
    -webkit-text-fill-color: transparent;
}

/* 全局按钮样式重置 */
taro-button-core,
button {
    margin: 0 !important;
    padding: 0 !important;
    line-height: inherit;
    display: flex;
    align-items: center;
    justify-content: center;
}

taro-button-core::after,
button::after {
    border: none;
}

taro-textarea-core > textarea,
.taro-textarea,
textarea.taro-textarea {
    resize: none !important;
}
`,sn=`
/* PC 宽屏适配 - 基础布局 */
@media (min-width: 769px) {
  html {
    font-size: 15px !important;
  }

  body {
    background-color: #f3f4f6 !important;
    display: flex !important;
    justify-content: center !important;
    align-items: center !important;
    min-height: 100vh !important;
  }
}
`,ln=`
/* PC 宽屏适配 - 手机框样式（有 TabBar 页面） */
@media (min-width: 769px) {
  .taro-tabbar__container {
    width: 375px !important;
    max-width: 375px !important;
    height: calc(100vh - 40px) !important;
    max-height: 900px !important;
    background-color: #fff !important;
    transform: translateX(0) !important;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1) !important;
    border-radius: 20px !important;
    overflow: hidden !important;
    position: relative !important;
  }

  .taro-tabbar__panel {
    height: 100% !important;
    overflow: auto !important;
  }
}

/* PC 宽屏适配 - Toast 定位到手机框范围内 */
@media (min-width: 769px) {
  body .toaster {
    left: 50% !important;
    right: auto !important;
    width: 375px !important;
    max-width: 375px !important;
    transform: translateX(-50%) !important;
    box-sizing: border-box !important;
  }
}

/* PC 宽屏适配 - 手机框样式（无 TabBar 页面，通过 JS 添加 no-tabbar 类） */
@media (min-width: 769px) {
  body.no-tabbar #app {
    width: 375px !important;
    max-width: 375px !important;
    height: calc(100vh - 40px) !important;
    max-height: 900px !important;
    background-color: #fff !important;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1) !important;
    border-radius: 20px !important;
    overflow: hidden !important;
    position: relative !important;
    transform: translateX(0) !important;
  }

  body.no-tabbar #app .taro_router {
    height: 100% !important;
    overflow: auto !important;
  }
}
`;function cn(){var i=document.createElement("style");i.innerHTML=un+sn+ln,document.head.appendChild(i)}function pn(){var i=function(){var e=!!document.querySelector(".taro-tabbar__container");document.body.classList.toggle("no-tabbar",!e)};i();var n=new MutationObserver(i);n.observe(document.body,{childList:!0,subtree:!0})}function dn(){cn(),pn()}function fn(){var i=q();if(i===D.WEAPP||i===D.TT)try{var n=X(),t=n.miniProgram.envVersion;console.log("[Debug] envVersion:",t),t!=="release"&&Y({enableDebug:!0})}catch(e){console.error("[Debug] 开启调试模式失败:",e)}}var gn={visible:!1,title:"",bgColor:"#ffffff",textStyle:"black",navStyle:"default",transparent:"none",leftIcon:"none"},vn=function(){var n,t=C();return(t==null||(n=t.config)===null||n===void 0?void 0:n.window)||{}},mn=function(){var n,t,e=(n=C())===null||n===void 0||(n=n.config)===null||n===void 0?void 0:n.tabBar;return new Set((e==null||(t=e.list)===null||t===void 0?void 0:t.map(function(o){return o.pagePath}))||[])},L=function(){var n,t=C();return(t==null||(n=t.config)===null||n===void 0||(n=n.pages)===null||n===void 0?void 0:n[0])||"pages/index/index"},y=function(n){return n.replace(/^\//,"")},bn=function(n,t,e,o){if(!n)return"none";var r=y(n),a=y(o),E=r===a,T=t.has(r)||t.has("/".concat(r)),f=e>1;return T||E?"none":f?"back":"home"},hn=function(){var n=b.useState(gn),t=j(n,2),e=t[0],o=t[1],r=b.useState(0),a=j(r,2),E=a[0],T=a[1],f=b.useCallback(function(){var s=g.getCurrentPages();if(s.length===0){o(function($){return O(O({},$),{},{visible:!1})});return}var c=s[s.length-1],A=(c==null?void 0:c.route)||"";if(A){var v=(c==null?void 0:c.config)||{},m=vn(),h=mn(),W=L(),x=y(A),k=y(W),G=x===k,U=h.has(x)||h.has("/".concat(x)),P=h.size<=1&&s.length<=1&&(G||U);o({visible:!P,title:document.title||v.navigationBarTitleText||m.navigationBarTitleText||"",bgColor:v.navigationBarBackgroundColor||m.navigationBarBackgroundColor||"#ffffff",textStyle:v.navigationBarTextStyle||m.navigationBarTextStyle||"black",navStyle:v.navigationStyle||m.navigationStyle||"default",transparent:v.transparentTitle||m.transparentTitle||"none",leftIcon:P?"none":bn(x,h,s.length,k)})}},[]);g.useDidShow(function(){f()}),g.usePageScroll(function(s){var c=s.scrollTop;e.transparent==="auto"&&T(Math.min(c/100,1))}),b.useEffect(function(){var s=null,c=new MutationObserver(function(){s&&clearTimeout(s),s=setTimeout(function(){f()},50)});return c.observe(document.head,{subtree:!0,childList:!0,characterData:!0}),f(),function(){c.disconnect(),s&&clearTimeout(s)}},[f]);var B=e.visible&&e.navStyle!=="custom";if(b.useEffect(function(){B?document.body.classList.add("h5-navbar-visible"):document.body.classList.remove("h5-navbar-visible")},[B]),!B)return u.jsx(u.Fragment,{});var S=e.textStyle==="white"?"#fff":"#333",I=e.textStyle==="white"?"text-white":"text-gray-800",V=function(){return e.transparent==="always"?{backgroundColor:"transparent"}:e.transparent==="auto"?{backgroundColor:e.bgColor,opacity:E}:{backgroundColor:e.bgColor}},z=function(){return g.navigateBack()},M=function(){var c=L();g.reLaunch({url:"/".concat(c)})};return u.jsxs(u.Fragment,{children:[u.jsxs(_,{className:"fixed top-0 left-0 right-0 h-11 flex items-center justify-center z-1000",style:V(),children:[e.leftIcon==="back"&&u.jsx(_,{className:"absolute left-2 top-1/2 -translate-y-1/2 p-1 flex items-center justify-center",onClick:z,children:u.jsx(J,{size:24,color:S})}),e.leftIcon==="home"&&u.jsx(_,{className:"absolute left-2 top-1/2 -translate-y-1/2 p-1 flex items-center justify-center",onClick:M,children:u.jsx(K,{size:22,color:S})}),u.jsx(Q,{className:"text-base font-medium max-w-3/5 truncate ".concat(I),children:e.title})]}),u.jsx(_,{className:"h-11 shrink-0"})]})},xn=function(n){var t=n.children;return u.jsxs(u.Fragment,{children:[u.jsx(hn,{}),t]})},_n=function(n){var t=n.children;return g.useLaunch(function(){fn(),dn()}),u.jsx(xn,{children:t})},yn=function(n){var t=n.children;return u.jsx(Z,{defaultColor:"#000",defaultSize:24,children:u.jsx(_n,{children:t})})},w=H.__taroAppConfig={router:{mode:"hash"},pages:["pages/index/index","pages/settings/index","pages/history/index","pages/knowledge/index","pages/memory/index","pages/skills/index","pages/projects/index","pages/projects/create"],window:{backgroundTextStyle:"light",navigationBarBackgroundColor:"#ffffff",navigationBarTitleText:"我的工作助手",navigationBarTextStyle:"black"}};w.routes=[Object.assign({path:"pages/index/index",load:function(){var i=d(l().m(function t(e,o){var r;return l().w(function(a){for(;;)switch(a.n){case 0:return a.n=1,p(()=>import("./index.60e029d8.js"),["./index.60e029d8.js","./vendors.f5906235.js","../css/vendors.8886af03.css","./common.3b575a10.js"],import.meta.url);case 1:return r=a.v,a.a(2,[r,e,o])}},t)}));function n(t,e){return i.apply(this,arguments)}return n}()},{navigationBarTitleText:"工作助手",navigationBarBackgroundColor:"#ffffff",navigationBarTextStyle:"black",backgroundColor:"#f7f7f8",enableShareAppMessage:!1,enableShareTimeline:!1}),Object.assign({path:"pages/settings/index",load:function(){var i=d(l().m(function t(e,o){var r;return l().w(function(a){for(;;)switch(a.n){case 0:return a.n=1,p(()=>import("./index.3883ce83.js"),["./index.3883ce83.js","./vendors.f5906235.js","../css/vendors.8886af03.css","./common.3b575a10.js","../css/index.6049fc3e.css"],import.meta.url);case 1:return r=a.v,a.a(2,[r,e,o])}},t)}));function n(t,e){return i.apply(this,arguments)}return n}()},{navigationBarTitleText:"设置",navigationBarBackgroundColor:"#ffffff",navigationBarTextStyle:"black",backgroundColor:"#ffffff"}),Object.assign({path:"pages/history/index",load:function(){var i=d(l().m(function t(e,o){var r;return l().w(function(a){for(;;)switch(a.n){case 0:return a.n=1,p(()=>import("./index.7634c2a2.js"),["./index.7634c2a2.js","./vendors.f5906235.js","../css/vendors.8886af03.css","./common.3b575a10.js"],import.meta.url);case 1:return r=a.v,a.a(2,[r,e,o])}},t)}));function n(t,e){return i.apply(this,arguments)}return n}()},{navigationBarTitleText:"历史对话"}),Object.assign({path:"pages/knowledge/index",load:function(){var i=d(l().m(function t(e,o){var r;return l().w(function(a){for(;;)switch(a.n){case 0:return a.n=1,p(()=>import("./index.111ebc35.js"),["./index.111ebc35.js","./vendors.f5906235.js","../css/vendors.8886af03.css","./common.3b575a10.js","../css/index.c4a7f7d9.css"],import.meta.url);case 1:return r=a.v,a.a(2,[r,e,o])}},t)}));function n(t,e){return i.apply(this,arguments)}return n}()},{navigationBarTitleText:"知识库",navigationBarBackgroundColor:"#ffffff",navigationBarTextStyle:"black",backgroundColor:"#ffffff"}),Object.assign({path:"pages/memory/index",load:function(){var i=d(l().m(function t(e,o){var r;return l().w(function(a){for(;;)switch(a.n){case 0:return a.n=1,p(()=>import("./index.2c4043e1.js"),["./index.2c4043e1.js","./vendors.f5906235.js","../css/vendors.8886af03.css","./common.3b575a10.js","../css/index.75ee6cfa.css"],import.meta.url);case 1:return r=a.v,a.a(2,[r,e,o])}},t)}));function n(t,e){return i.apply(this,arguments)}return n}()},{navigationBarTitleText:"我的记忆",navigationBarBackgroundColor:"#ffffff",navigationBarTextStyle:"black",backgroundColor:"#ffffff"}),Object.assign({path:"pages/skills/index",load:function(){var i=d(l().m(function t(e,o){var r;return l().w(function(a){for(;;)switch(a.n){case 0:return a.n=1,p(()=>import("./index.ff7672fe.js"),["./index.ff7672fe.js","./vendors.f5906235.js","../css/vendors.8886af03.css","./common.3b575a10.js"],import.meta.url);case 1:return r=a.v,a.a(2,[r,e,o])}},t)}));function n(t,e){return i.apply(this,arguments)}return n}()},{navigationBarTitleText:"技能库"}),Object.assign({path:"pages/projects/index",load:function(){var i=d(l().m(function t(e,o){var r;return l().w(function(a){for(;;)switch(a.n){case 0:return a.n=1,p(()=>import("./index.8d3b0423.js"),["./index.8d3b0423.js","./vendors.f5906235.js","../css/vendors.8886af03.css","./common.3b575a10.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return r=a.v,a.a(2,[r,e,o])}},t)}));function n(t,e){return i.apply(this,arguments)}return n}()},{navigationBarTitleText:"项目"}),Object.assign({path:"pages/projects/create",load:function(){var i=d(l().m(function t(e,o){var r;return l().w(function(a){for(;;)switch(a.n){case 0:return a.n=1,p(()=>import("./create.b928794b.js"),["./create.b928794b.js","./vendors.f5906235.js","../css/vendors.8886af03.css","./common.3b575a10.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return r=a.v,a.a(2,[r,e,o])}},t)}));function n(t,e){return i.apply(this,arguments)}return n}()},{navigationBarTitleText:"新建项目"})];Object.assign(N,{findDOMNode:F.findDOMNode,render:F.render,unstable_batchedUpdates:F.unstable_batchedUpdates});nn();var wn=tn(yn,R,N,w),En=en({window:H});an(w);rn(En,wn,w,R);on({designWidth:750,deviceRatio:{375:2,640:1.17,750:1,828:.905},baseFontSize:20,unitPrecision:void 0,targetUnit:void 0});
